#include "MainPage.h"
#include "SignUp.h"
#include "SignIn.h"
MainPage::MainPage()
{
    //ctor
}

MainPage::~MainPage()
{
    //dtor
}
#include<iostream>
#include<stdlib.h>
#include<dir.h>
#include<dirent.h>
#include<stdlib.h>
#include<string.h>
#include<iomanip>
#include<graphics.h>
#include<fstream>
using namespace std;

int main()
{
    int ch,e=0;
    DIR *account=opendir("Accounts");//DIR(directory) type pointer to check existence of "Accounts" directory
    if(account==NULL)
    {
        mkdir("Accounts");//creating "Accounts" directory
    }

    DIR *admin=opendir("Accounts/Admin");//DIR(directory type pointer to check existence of "Admin" folder within "Accounts" folder
    if(admin==NULL)
    {
        mkdir("Accounts/Admin");//making of "Admin" folder
        ofstream afile("Accounts/Admin/Profile.txt");//creating profile.txt file within "Admin" folder
        afile<<"This is Admin File\n";//writing 1st line of the file
        afile<<"Admin\n";//writing 2nd line of the file
        afile<<"SKAGAKRM\n";//writing 3rd line of the file
        afile.close();//closing the file.
    }
    closedir(admin);//closing "Admin" folder.
    closedir(account);//closing "Accounts" folder.
    while(e==0)
    {
        cout<<"1.SIGN UP\n";
        cout<<"2.SIGN IN\n";
        cout<<"3.EXIT\n";

        cout<<"PLEASE ENTER YOUR CHOICE\n";
        cin>>ch;

        system("cls");

        switch(ch)
        {
        case 1:
        {
            SignUp ob;//Object of Class SignUp
            ob.getdetails();//Calling getdetails function of SignUp class.
            break;
        }

        case 2:
        {
            SignIn ob1;//Object of Class SignIn
            ob1.Signinscreen();//calling Signinscreen function of class SignIn
            break;
        }
        case 3:
            system("cls");
            cout<<"THANK YOU!\n";
            e=1;//terminating condition of the entire program

        }

    }
}

