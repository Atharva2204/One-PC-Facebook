#include "SignIn.h"

SignIn::SignIn()
{
    //ctor
}

SignIn::~SignIn()
{
    //dtor
}
#include<iostream>
#include<string>
#include<fstream>
#include<dirent.h>
#include<fstream>
#include<stdlib.h>
#include<string.h>
#include<limits>
#include<cctype>
#include<locale>
#include<cstring>
#include<sstream>
using namespace std;
int SignIn::enterdetails()
{
    int flag=0,attempt=4,attempt1=4;
    bool authentification=false;
    char ch;
    while(flag==0&&attempt!=0)
    {
        cout<<"PLEASE ENTER YOUR USERNAME\n";
        cin>>uname;
        //uname2=uname;
        string foldpath="Accounts/"+uname;
        char foldname[50]= {};
        foldpath.copy(foldname,foldpath.length(),0);
        DIR *dname=opendir(foldname);
        try
        {
            if(dname==NULL)
            {
                attempt--;
                throw dname;
            }
            else
            {
                flag=1;
            }
        }
        catch(DIR *dname)
        {
            cout<<"THE ENTERED USERNAME DOES NOT EXIST!\n";
            cout<<"ATTEMPTS REMAINING:-"<<attempt<<endl;
            system("pause");
            system("cls");
        }
    }
    flag=0;
    if(attempt!=0)
    {
        while(flag==0&&attempt1!=0)
        {
            int lineno=0;
            cout<<"PLEASE ENTER YOUR PASSWORD\n";
            cin>>password;
            string filepath="Accounts/"+uname+"/Profile.txt";
            char filename[50]= {};
            filepath.copy(filename,filepath.length(),0);
            ifstream file(filename);
            while(lineno<5)
            {
                getline(file,chkpass);
                if(lineno==2)
                    break;
                lineno++;
            }
            try
            {
                if(chkpass==password)
                    flag=1;
                else
                {

                    attempt1--;
                    throw password;
                }
            }
            catch(string password)
            {
                cout<<"THE ENTERED PASSWORD IS INCORRECT!\n";
                cout<<"ATTEMPTS REMAINING:-"<<attempt1<<endl;
                system("pause");
                system("cls");
                if(attempt1!=0)
                {
                    cout<<"PLEASE ENTER YOUR USERNAME\n";
                    cout<<uname<<endl;

                }
            }
        }
        //cout<<"AUTHENTIFICATION COMPLETE\n";
        //authentification=true;
        //return(authentification);
        //system("pause");
    }
    if(flag==1)
    {
        cout<<"AUTHENTIFICATION COMPLETE\n";
        system("pause");
        system("cls");
        return 1;

    }
}
void SignIn::Viewdetails()
{
    char arr1[50],arr2[50],arr3[50],arr4[50],arr5[50];

    string foldpath="Accounts/"+uname+"/Profile.txt";
    char foldname[50]= {};
    foldpath.copy(foldname,foldpath.length(),0);
    ifstream obj(foldname);

    obj.getline(arr1,50);
    cout<<"Name: "<<arr1<<endl;
    obj.getline(arr2,50);
    cout<<"Username: "<<arr2<<endl;
    obj.getline(arr3,50);
    cout<<"Password: "<<arr3<<endl;
    obj.getline(arr4,50);
    cout<<"Birthdate: "<<arr4<<endl;
    obj.getline(arr5,50);
    cout<<"Gender: "<<arr5<<endl;
    system("pause");

}
void SignIn::edit_name()
{
    //system("cls");
    string fname,mname,lname,upfname,upmname,uplname,upfulname;
    char arr2[50]= {};
    int flag=0,flag1=0;
    int key=0;
    string str_found,str_replace;
    size_t pos;
    ostringstream text;
    string foldpath="Accounts/"+uname+"/Profile.txt";
    char foldname[50]= {};
    foldpath.copy(foldname,foldpath.length(),0);
    ifstream obj1(foldname);
    text<<obj1.rdbuf();
    string str=text.str();


    while(key==0)
    {
        //cin.ignore();
        //cout<<"\nEnter current name:";
        // cin.getline(arr1,50);
        //cin.ignore();
        cout<<"ENTER CURRENT DETAILS\n";
        cout<<"FIRST NAME:-";
        cin>>fname;
        cout<<"\n";
        cout<<"MIDDLE NAME:-";
        cin>>mname;
        cout<<"\n";
        cout<<"LAST NAME:-";
        cin>>lname;
        cout<<"\n";

        //str_found=arr1;
        //cin.getline(str_found);
        //cout<<arr1<<endl;
        //cout<<str_found<<endl;
        str_found=fname+" "+mname+" "+lname;
        pos=str.find(str_found);
        if(pos==string::npos)
        {
            key=0;
            cout<<"\nEntered name not found.Please enter again"<<endl;
            system("pause");
            system("cls");
        }
        else
            key=1;
    }


    while(flag==0 && key==1)
    {
        flag1=0;
        cout<<"Enter UPDATED NAME:\n";
        cout<<"FIRST NAME:-";
        cin>>upfname;
        cout<<"\n";
        cout<<"MIDDLE NAME:-";
        cin>>upmname;
        cout<<"\n";
        cout<<"LAST NAME:-";
        cin>>uplname;
        cout<<"\n";
        upfulname=upfname+" "+upmname+" "+uplname;
        upfulname.copy(arr2,upfulname.length(),0);

        for(int i=0; i<strlen(arr2); i++)
        {
            // flag=0;

            if(isdigit(arr2[i])!=0 || ispunct(arr2[i]!=0))
            {
                //cout<<fname.at(i);
                flag1=1;
            }
        }
        try
        {
            if(flag1==0)
                flag=1;
            else
                throw arr2;
        }
        catch(char arr2[30])
        {
            cout<<"NAME CAN CONTAIN ONLY ALPHABETS!\n";
            //cout<<"PRESS ENTER TO CONTINUE\n";
            system("pause");
            system("cls");
            cout<<"ENTER CURRENT DETAILS\n";
            cout<<"FIRST NAME:-";
            cout<<fname<<endl;
            cout<<"\n";
            cout<<"MIDDLE NAME:-";
            cout<<mname<<endl;
            cout<<"\n";
            cout<<"LAST NAME:-";
            cout<<lname<<endl;
            cout<<"\n";

        }
    }

    //if(flag==1)
    //{
    str_replace=arr2;

    str.replace(pos,string(str_found).length(),str_replace);
    obj1.close();
    ofstream obj2(foldname);
    obj2<<str;
    cout<<"\nYour name has been successfully updated!"<<endl;


    system("pause");

    // }


}
void SignIn::edit_username()
{
    string arr1,arr2;
    int flag=0;
    int key=0;
    string str_found,str_replace;
    size_t pos;


    ostringstream text;
    string foldpath="Accounts/"+uname+"/Profile.txt";
    char foldname[50]= {};
    foldpath.copy(foldname,foldpath.length(),0);
    ifstream obj1(foldname);
    text<<obj1.rdbuf();
    string str=text.str();

    while(key==0)
    {
        cout<<"\nEnter current username:";
        cin>>arr1;
        str_found=arr1;
        pos=str.find(str_found);


        if(pos==string::npos)
        {
            key=0;
            cout<<"\nEntered username not found.Please enter again"<<endl;
            system("pause");
            system("cls");
        }
        else
            key=1;
    }




    while(flag==0&&key==1)
    {
        cout<<"Enter updated username\n";
        cin>>arr2;
        cin.ignore();
        string fpath="Accounts/"+arr2;
        char checkuname[50]= {};
        fpath.copy(checkuname,fpath.length(),0);
        DIR *validity=opendir(checkuname);
        try
        {
            if(validity==NULL)
            {
                flag=1;
            }
            else
            {

                throw validity;
            }


        }
        catch(DIR *validity)
        {
            cout<<"THIS USERNAME ALREADY EXISTS PLEASE ENTER ANOTHER USERNAME!\n";
            system("pause");

        }
    }

    str_replace=arr2;

    str.replace(pos,string(str_found).length(),str_replace);
    obj1.close();
    ofstream obj2(foldname);
    obj2<<str;
    cout<<"\nYour username has been successfully updated!"<<endl;
    uname=arr2;
    foldpath="Accounts/"+uname;
    foldname[50]= {};
    foldpath.copy(foldname,foldpath.length(),0);
    DIR *dname=opendir(foldname);

    system("pause");

}
void SignIn::edit_password()
{
    char arr1[20],arr2[20],arr3[20];
    int  flag=0;
    int flag2=0;
    int key=0;
    string str_found,str_replace;
    size_t pos;

    ostringstream text;
    string foldpath="Accounts/"+uname+"/Profile.txt";
    char foldname[50]= {};
    foldpath.copy(foldname,foldpath.length(),0);
    ifstream obj1(foldname);
    text<<obj1.rdbuf();
    string str=text.str();

    while(key==0)
    {
        cout<<"\nEnter current password:";
        //cin.ignore();
        cin>>arr1;
        //cout<<arr1;
        str_found=arr1;
        pos=str.find(str_found);

        if(pos==string::npos)
        {
            key=0;
            cout<<"\nEntered password not found.Please enter again"<<endl;
            system("pause");
            system("cls");
        }
        else
            key=1;
    }

    flag=0;
    while(flag==0)
    {
        while(flag2==0)
        {
            cout<<"\nEnter NEW password :";
            cin>>arr2;
            int nctr=0,sctr=0,capctr=0;

            try
            {

                for(int i=0; i<strlen(arr2); i++)
                {
                    if(arr2[i] >= 65 && arr2[i] <= 90)
                        capctr++;
                    else if((isdigit(arr2[i]))== 1)
                        nctr++;
                    else if(isalnum(arr2[i] )== 0)
                        sctr++;

                }
                if(capctr==0||nctr==0||sctr==0||(strlen(arr2)<8))
                    throw arr2;
                else
                {
                    flag2=1;
                    flag=1;
                }
            }
            catch(char arr2[20])
            {
                cout<<"PASSWORD SHOULD BE OF MIN 8 CHARACTERS INCLUDING 1 NUMBER,1 SYMBOL & 1 CAPITAL LETTER\n";
                system("pause");
                system("cls");
                cout<<"\nEnter current password:";
                cout<<arr1<<endl;
            }

        }
        cout<<"\nConfirm NEW password :";
        cin>>arr3;

        if((strcmp(arr2,arr3)==0))
            flag=1;
        else
        {
            flag=0;
            cout<<"\nThe re-entered password does not match new password,please enter again"<<endl;

            system("pause") ;
            system("cls");
            cout<<"\nEnter current password:";
            cout<<arr1<<endl;
            cout<<"\nEnter NEW password :";
            cout<<arr2<<endl;


        }


    }


    if(flag==1)
    {
        str_replace=arr2;

        str.replace(pos,string(str_found).length(),str_replace);
        obj1.close();
        ofstream obj2(foldname);
        obj2<<str;
        cout<<"\nYour password has been successfully updated!"<<endl;
        system("pause");
    }


}
std::fstream& GotoLine(std::fstream& file, unsigned int num)
{
    file.seekg(std::ios::beg);
    for(int i=0; i < num - 1; ++i)
    {
        file.ignore(std::numeric_limits<std::streamsize>::max(),'\n');
    }
    return file;
}
void SignIn::edit_gender()
{
    system("cls");
    char arr1[10],arr2[10];
    int flag=0;
    int flag2=0;
    //char str1[10]="Male";
    //char str2[10]="Female";
    //char str3[10]="Other";
    char str1[10]="male";
    char str2[10]="female";
    char str3[10]="other";
    int key=0;
    string str_found,str_replace;
    char temp[10];
    size_t pos,pos1=0;
    size_t len=0;

    ostringstream text;
    string foldpath="Accounts/"+uname+"/Profile.txt";
    char foldname[50]= {};
    foldpath.copy(foldname,foldpath.length(),0);
    fstream obj1(foldname);
    text<<obj1.rdbuf();
    string str=text.str();
    GotoLine(obj1,5);
    char line5[10];
    obj1>>line5;
    cin.get();



    while(flag2==0)
    {

label:
        cout<<"\nEnter current gender(male/female/other):";
        //cin.ignore();
        cin>>arr1;
        strlwr(arr1);



        try
        {
            if((strcmp(arr1,str1)==0) || (strcmp(arr1,str2)==0) || (strcmp(arr1,str3)==0))
            {
                flag2=1;
            }

            else
                throw arr1;
        }
        catch(char arr1[10])
        {
            cout<<"PLEASE ENTER A  VALID GENDER\n";
            system("pause");
            system("cls");
        }
    }

    while(key==0)
    {
        try
        {
            if((strcmp(arr1,line5)) == 0)
            {
                key=1;

                str_found=line5;
                pos=str.find(str_found);
            }
            else
            {
                key=0;
                throw arr1;

            }
        }
        catch(char arr1[10])
        {
            cout<<"Current gender not found.Please enter again.."<<endl;
            system("pause");
            system("cls");
            goto label;
        }

    }

    /* pos=str.find(str_found);
     if(pos==string::npos)
         {
             key=0;
             cout<<"\nEntered gender not found.Please enter again"<<endl;
             system("pause");
             system("cls");
         }
         else
             key=1;
    }*/

    while(flag==0)
    {
        cout<<"\nEnter UPDATED gender(Male/Female/Other) :";
        cin>>arr2;
        strlwr(arr2);

        try
        {
            if((strcmp(arr2,str1)==0) || (strcmp(arr2,str2)==0) || (strcmp(arr2,str3)==0) )
            {
                flag=1;
            }

            else
                throw arr2;
        }
        catch(char arr2[10])
        {
            cout<<"PLEASE ENTER A  VALID GENDER\n";
            system("pause");
            system("cls");
            cout<<"\nEnter current gender(male/female/other):";
            cout<<arr1<<endl;
            strlwr(arr1);



        }
    }
    if(flag==1)
    {
        str_replace=arr2;

        str.replace(pos,string(str_found).length(),str_replace);
        obj1.close();
        ofstream obj2(foldname);
        obj2<<str;
        cout<<"\nYour gender has been successfully updated!"<<endl;
        system("pause");
    }


}
void SignIn::edit_details()
{
    int ch;
    cout<<"EDIT SECTION:-";
    cout<<"\n1.Edit name"<<endl<<"2.Edit username"<<endl<<"3.Edit password"<<endl
        <<"4.Edit Gender"<<endl;
    cout<<"PLEASE SELECT WHAT DETAIL YOU WANT TO EDIT\n";
    cin>>ch;
    switch (ch)
    {
    case 1:
    {
        system("cls");
        edit_name();
        break;
    }
    case 2:
    {
        edit_username();
        break;
    }
    case 3:
    {
        system("cls");
        edit_password();
        break;
    }

    case 4:
    {
        edit_gender();
        break;
    }
        // case 6
    }

}


void SignIn::AfterLogin()
{
    if(uname!="Admin")
    {
        int e=0,ch;
        while(e==0)
        {
            cout<<"WELCOME:-"<<uname<<endl;
            cout<<"1.VIEW DETAILS\n";
            cout<<"2.EDIT DETAILS\n";
            cout<<"3.CHAT\n";
            cout<<"4.ADD FRIENDS\n";
            cout<<"5.FRIEND LIST\n";
            cout<<"6.LOGOUT\n";
            cout<<"ENTER YOUR CHOICE\n";
            cin>>ch;

            switch(ch)
            {
            case 1:
            {
                //SignIn ob1;
                system("cls");
                Viewdetails();
                system("cls");
                break;
            }
            case 2:
            {
                system("cls");
                edit_details();
                system("cls");
                break;
            }

            case 6:
                system("cls");
                e=1;

            }
        }
    }
    else
    {
        DIR *profilename=opendir("Accounts/");
        struct dirent *direntry;
        int s=0,ch1,flag=0,dflag=0;
        while(s==0)
        {
            cout<<"WELCOME:-ADMIN\n";
            cout<<"1.VIEW PROFILE DETAILS\n";
            cout<<"2.DELETE PROFILE\n";
            cout<<"3.LOGOUT\n";
            cout<<"PLEASE ENTER YOUR CHOICE\n";
            cin>>ch1;

            switch(ch1)
            {
            case 1:
            {
                string filepath,dirname;
                string personname;
                int pronum=0;
                profilename=opendir("Accounts/");
                readdir(profilename);
                readdir(profilename);
                system("cls");
                while(direntry=readdir(profilename))
                {
                    if(strcmp(direntry->d_name,"Admin")!=0)
                    {
                        pronum++;
                    }
                }
                if(pronum!=0)
                {
                    cout<<"PROFILE DETAILS ARE AS FOLLOWS:-\n";
                    cout<<"CURRENT PROFILES ON THE SYSTEM:-"<<pronum<<endl;
                    pronum=0;
                    closedir(profilename);
                    direntry=NULL;
                    profilename=opendir("Accounts/");
                    readdir(profilename);
                    readdir(profilename);
                    while(direntry=readdir(profilename))
                    {
                        if(strcmp(direntry->d_name,"Admin")!=0)
                        {
                            pronum++;
                            cout<<pronum<<"."<<direntry->d_name;
                            dirname=direntry->d_name;
                            filepath="Accounts/"+dirname+"/Profile.txt";
                            char fpath[50]= {};
                            filepath.copy(fpath,filepath.length(),0);
                            ifstream file(fpath);
                            getline(file,personname);
                            file.close();
                            cout<<"("<<personname<<")"<<endl;
                        }
                    }

                    closedir(profilename);
                }

                else
                {
                    cout<<"THERE ARE CURRENTLY 0 PROFILES IN THE SYSTEM!\n";
                }
                system("pause");
                system("cls");
                break;
            }

            case 2:
            {
                system("cls");
                DIR *sub_dir;
                string filepath,dirname,personname,delfoldpath;
                char fpath[50]= {};
                struct dirent *sub_direntry;
                profilename=opendir("Accounts/");
                readdir(profilename);
                readdir(profilename);
                int pronum=0;
                bool notdigi=false;
                int delprofile=0;
                system("cls");
                while(direntry=readdir(profilename))
                {
                    pronum++;
                }
                closedir(profilename);
                profilename=opendir("Accounts/");
                readdir(profilename);
                readdir(profilename);
                if(pronum!=1)
                {
                    pronum=0;
                    cout<<"PROFILES ARE LISTED BELOW\n";
                    while(direntry=readdir(profilename))
                    {
                        if(strcmp(direntry->d_name,"Admin")!=0)
                        {
                            pronum++;
                            cout<<pronum<<"."<<direntry->d_name;
                            dirname=direntry->d_name;
                            filepath="Accounts/"+dirname+"/Profile.txt";
                            filepath.copy(fpath,filepath.length(),0);
                            ifstream file(fpath);
                            getline(file,personname);
                            file.close();
                            cout<<"("<<personname<<")"<<endl;
                        }
                    }
                    closedir(profilename);
                    while(flag==0)
                    {



                        while(true)
                        {
                            delprofile=0;
                            cout<<"PLEASE ENTER THE PROFILE YOU WANT TO DELETE\n";
                            cin>>delprofile;
                            if(cin.good())
                                break;
                            else
                            {
                                cout<<"ENTER AN INTEGER!\n";
                                system("pause");
                                system("cls");
                                cin.clear();
                                cin.ignore(numeric_limits<streamsize>::max(),'\n');
                                profilename=opendir("Accounts/");
                                readdir(profilename);
                                readdir(profilename);
                                pronum=0;
                                delprofile=0;
                                cout<<"PROFILES ARE LISTED BELOW\n";
                                while(direntry=readdir(profilename))
                                {
                                    if(strcmp(direntry->d_name,"Admin")!=0)
                                    {
                                        pronum++;
                                        cout<<pronum<<"."<<direntry->d_name;
                                        dirname=direntry->d_name;
                                        filepath="Accounts/"+dirname+"/Profile.txt";
                                        filepath.copy(fpath,filepath.length(),0);
                                        ifstream file(fpath);
                                        getline(file,personname);
                                        file.close();
                                        cout<<"("<<personname<<")"<<endl;
                                    }
                                }

                            }
                        }

                        try
                        {
                            //if(isdigit(delprofile)!=0)
                            // notdigi=true;
                            //throw notdigi;
                            if(delprofile>pronum||delprofile<=0)
                                throw delprofile;
                            else
                                flag=1;
                        }
                        catch(int delprofile)
                        {
                            cout<<"PLEASE ENTER A VALID PROFILE NUMBER TO BE DELETED\n";
                            system("pause");
                            system("cls");
                            profilename=opendir("Accounts/");
                            readdir(profilename);
                            readdir(profilename);
                            pronum=0;
                            delprofile=0;
                            cout<<"PROFILES ARE LISTED BELOW\n";
                            while(direntry=readdir(profilename))
                            {
                                if(strcmp(direntry->d_name,"Admin")!=0)
                                {
                                    pronum++;
                                    cout<<pronum<<"."<<direntry->d_name;
                                    dirname=direntry->d_name;
                                    filepath="Accounts/"+dirname+"/Profile.txt";
                                    filepath.copy(fpath,filepath.length(),0);
                                    ifstream file(fpath);
                                    getline(file,personname);
                                    file.close();
                                    cout<<"("<<personname<<")"<<endl;
                                }
                            }

                        }
                        closedir(profilename);
                    }
                    flag=0;
                    pronum=0;
                    char delfolder[50]= {};
                    profilename=opendir("Accounts/");
                    readdir(profilename);
                    readdir(profilename);
                    while(direntry=readdir(profilename))
                    {
                        dirname=direntry->d_name;
                        delfoldpath="Accounts/"+dirname+"/";
                        string delfoldpath1="Accounts/"+dirname;
                        char delfpath1[50]= {};
                        delfoldpath1.copy(delfpath1,delfoldpath1.length(),0);
                        char delfpath[50]= {};
                        delfoldpath.copy(delfpath,delfoldpath.length(),0);
                        sub_dir=opendir(delfpath);
                        if(dirname!="Admin")
                        {
                            pronum++;
                            if(pronum==delprofile)
                            {
                                while(sub_direntry=readdir(sub_dir))
                                {
                                    string filename=sub_direntry->d_name;
                                    string filepath="Accounts/"+dirname+"/"+filename;
                                    char delfile[50]= {};
                                    filepath.copy(delfile,filepath.length(),0);
                                    remove(delfile);
                                }
                                rmdir(delfpath1);
                                dflag=1;
                                break;
                            }

                        }
                    }
                    if(dflag==1)
                    {
                        cout<<"THE PROFILE WAS SUCCESSFULLY DELETED\n";
                        closedir(sub_dir);
                        closedir(profilename);
                        system("pause");
                        system("cls");
                        break;
                    }
                    dflag=0;

                }
                else
                {
                    cout<<"THERE ARE CURRENTLY 0 PROFILES IN THE SYSTEM!\n";
                    system("pause");
                    system("cls");
                    break;
                }
            }

            case 3:
                s=1;
                system("cls");
                break;

            }




            // system("pause");
        }
    }
}



int SignIn::Signinscreen()
{
    int e=0,ch,authentification;
    while(e==0)
    {


        cout<<"1.AUTHENTICATE\n";
        cout<<"2.GO  BACK\n";
        cout<<"ENTER YOUR CHOICE\n";
        cin>>ch;

        switch(ch)
        {
        case 1:
        {
            SignIn ob;
            system("cls");
            authentification=ob.enterdetails();
            if(authentification==1)
            {
                ob.AfterLogin();
                e=1;
            }
            break;
        }

        case 2:
            system("cls");
            return 0;

        }
    }

}
