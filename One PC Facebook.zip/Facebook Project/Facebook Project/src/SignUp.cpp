#include "SignUp.h"

SignUp::SignUp()
{

    //ctor
}

SignUp::~SignUp()
{
    //dtor
}
#include<iostream>
#include<ctime>
#include<fstream>
#include<dir.h>
#include<string>
#include<stdlib.h>
#include<dirent.h>
#include<sstream>
#include<string.h>
#include<limits>
//#include<dos.h>
//#include<string>
using namespace std;
void SignUp::getdetails()
{
    int flag=0,flag1=0;
    cout<<"PLEASE ENTER YOUR DETAILS BELOW\n";
    while(flag==0)
    {

        flag1=0;
        cout<<"1>FIRST NAME:-";
        cin>>fname;
        int len=fname.length();
        for(int i=0; i<len; i++)
        {
            if(isalpha(fname.at(i))==0)
            {
                flag1=1;
            }
        }
        try
        {
            if(flag1==0)
                flag=1;
            else
                throw fname;
        }
        catch(string fname)
        {
            cout<<"NAME CAN CONTAIN ONLY ALPHABETS!\n";
            system("pause");
            system("cls");
            cout<<"PLEASE ENTER YOUR DETAILS BELOW\n";

        }
    }
    flag=0;
    cout<<"\n";
    while(flag==0)
    {

        flag1=0;
        cout<<"2>MIDDLE NAME:-";
        cin>>mname;
        int len=mname.length();
        for(int i=0; i<len; i++)
        {
            if(isalpha(mname.at(i))==0)
            {
                flag1=1;
            }
        }
        try
        {
            if(flag1==0)
                flag=1;
            else
                throw mname;
        }
        catch(string mname)
        {
            cout<<"NAME CAN CONTAIN ONLY ALPHABETS!\n";
            system("pause");
            system("cls");
            cout<<"PLEASE ENTER YOUR DETAILS BELOW\n";
            cout<<"1>FIRST NAME:-";
            cout<<fname<<endl;
            cout<<"\n";
        }
    }
    flag=0;
    cout<<"\n";
    while(flag==0)
    {
        flag1=0;
        cout<<"3>LAST NAME:-";
        cin>>lname;
        int len=lname.length();
        for(int i=0; i<len; i++)
        {
            if(isalpha(lname.at(i))==0)
            {
                flag1=1;
            }
        }
        try
        {
            if(flag1==0)
                flag=1;
            else
                throw lname;
        }
        catch(string lname)
        {
            cout<<"NAME CAN CONTAIN ONLY ALPHABETS!\n";
            system("pause");
            system("cls");
            cout<<"PLEASE ENTER YOUR DETAILS BELOW\n";
            cout<<"1>FIRST NAME:-";
            cout<<fname<<endl;
            cout<<"\n";
            cout<<"2>MIDDLE NAME:-";
            cout<<mname<<endl;
            cout<<"\n";



        }
    }
    flag=0;
    cout<<"\n";
    while(flag==0)
    {
        cout<<"4>USERNAME:-";
        cin>>uname;
        cin.ignore();
        string fpath="Accounts/"+uname;
        char checkuname[50]= {};
        fpath.copy(checkuname,fpath.length(),0);
        DIR *validity=opendir(checkuname);
//        for(int i=0;i<uname.length)
        try
        {
            if(validity==NULL)
            {
                flag=1;
            }
            else
            {

                throw validity;
            }
        }
        catch(DIR *validity)
        {
            cout<<"THIS USERNAME ALREADY EXISTS PLEASE ENTER ANOTHER USERNAME!\n";
            system("pause");
            system("cls");
            cout<<"PLEASE ENTER YOUR DETAILS BELOW\n";
            cout<<"1>FIRST NAME:-";
            cout<<fname<<endl;
            cout<<"\n";
            cout<<"2>MIDDLE NAME:-";
            cout<<mname<<endl;
            cout<<"\n";
            cout<<"3>LAST NAME:-";
            cout<<lname<<endl;
            cout<<"\n";


        }
    }
    flag=0;
    cout<<"\n";
    while(flag==0)
    {
        bool pflag=false;
        int nctr=0,sctr=0,capctr=0,plen,eight=0,numcap=0,numsymb=0,symbcap=0,numcapl=0,numsymbl=0,symbcapl=0;
        cout<<"5>PASSWORD:-";
        cin>>password;
        cin.ignore();
        plen=password.length();
        try
        {
            for(int i=0; i<plen; i++)
            {
                if(password.at(i)>=65&&password.at(i)<=90)
                    capctr++;
                else if(isdigit(password.at(i))==1)
                    nctr++;
                else if(isalnum(password.at(i))==0)
                    sctr++;

            }
            if(capctr==0||nctr==0||sctr==0||password.length()<8)
                throw password;
            else
                flag=1;
        }
        catch(string password)
        {
            cout<<"PASSWORD SHOULD BE OF MIN 8 CHARACTERS INCLUDING 1 NUMBER,1 SYMBOL & 1 CAPITAL LETTER\n";
            system("pause");
            system("cls");
            cout<<"PLEASE ENTER YOUR DETAILS BELOW\n";
            cout<<"1>FIRST NAME:-";
            cout<<fname<<endl;
            cout<<"\n";
            cout<<"2>MIDDLE NAME:-";
            cout<<mname<<endl;
            cout<<"\n";
            cout<<"3>LAST NAME:-";
            cout<<lname<<endl;
            cout<<"\n";
            cout<<"4>USERNAME:-";
            cout<<uname<<endl;
            cout<<"\n";
        }

    }
    cout<<"\n";

    flag=0;
    cout<<"ENTER YOUR DATE OF BIRTH DETAILS BELOW\n";
    cout<<"\n";
    while(flag==0)
    {
        while(true)
        {
            cout<<"6>DATE:-";
            cin>>day;
            if(cin.good())
                break;
            else
            {
                cout<<"INVALID INPUT\n";
                system("pause");
                system("cls");
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(),'\n');
                cout<<"PLEASE ENTER YOUR DETAILS BELOW\n";
                cout<<"1>FIRST NAME:-";
                cout<<fname<<endl;
                cout<<"\n";
                cout<<"2>MIDDLE NAME:-";
                cout<<mname<<endl;
                cout<<"\n";
                cout<<"3>LAST NAME:-";
                cout<<lname<<endl;
                cout<<"\n";
                cout<<"4>USERNAME:-";
                cout<<uname<<endl;
                cout<<"\n";
                cout<<"5>PASSWORD:-";
                cout<<password<<endl;
                cout<<"\n";
                cout<<"ENTER YOUR DATE OF BIRTH DETAILS BELOW\n";
                cout<<"\n";


            }
        }
        try
        {
            if(day<=0||day>31)
                throw day;
            else
                flag=1;
        }
        catch(int day)
        {
            cout<<"PLEASE ENTER A VALID DATE\n";
            system("pause");
            system("cls");
            cout<<"PLEASE ENTER YOUR DETAILS BELOW\n";
            cout<<"1>FIRST NAME:-";
            cout<<fname<<endl;
            cout<<"\n";
            cout<<"2>MIDDLE NAME:-";
            cout<<mname<<endl;
            cout<<"\n";
            cout<<"3>LAST NAME:-";
            cout<<lname<<endl;
            cout<<"\n";
            cout<<"4>USERNAME:-";
            cout<<uname<<endl;
            cout<<"\n";
            cout<<"5>PASSWORD:-";
            cout<<password<<endl;
            cout<<"\n";
            cout<<"ENTER YOUR DATE OF BIRTH DETAILS BELOW\n";
            cout<<"\n";



        }

    }
    cout<<"\n";
    flag=0;
    while(flag==0)
    {
        while(true)
        {
            cout<<"7>MONTH:-";
            cin>>month;
            if(cin.good())
                break;
            else
            {
                cout<<"INVALID INPUT\n";
                system("pause");
                system("cls");
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(),'\n');
                cout<<"PLEASE ENTER YOUR DETAILS BELOW\n";
                cout<<"1>FIRST NAME:-";
                cout<<fname<<endl;
                cout<<"\n";
                cout<<"2>MIDDLE NAME:-";
                cout<<mname<<endl;
                cout<<"\n";
                cout<<"3>LAST NAME:-";
                cout<<lname<<endl;
                cout<<"\n";
                cout<<"4>USERNAME:-";
                cout<<uname<<endl;
                cout<<"\n";
                cout<<"5>PASSWORD:-";
                cout<<password<<endl;
                cout<<"\n";
                cout<<"ENTER YOUR DATE OF BIRTH DETAILS BELOW\n";
                cout<<"\n";
                cout<<"6>DATE:-";
                cout<<day<<endl;
                cout<<"\n";



            }
        }

        try
        {
            if(month<=0||month>12)
                throw month;
            else
                flag=1;

        }
        catch(int month)
        {
            cout<<"PLEASE ENTER A VALID MONTH\n";
            system("pause");
            system("cls");
            cout<<"PLEASE ENTER YOUR DETAILS BELOW\n";
            cout<<"1>FIRST NAME:-";
            cout<<fname<<endl;
            cout<<"\n";
            cout<<"2>MIDDLE NAME:-";
            cout<<mname<<endl;
            cout<<"\n";
            cout<<"3>LAST NAME:-";
            cout<<lname<<endl;
            cout<<"\n";
            cout<<"4>USERNAME:-";
            cout<<uname<<endl;
            cout<<"\n";
            cout<<"5>PASSWORD:-";
            cout<<password<<endl;
            cout<<"\n";
            cout<<"ENTER YOUR DATE OF BIRTH DETAILS BELOW\n";
            cout<<"\n";
            cout<<"6>DATE:-";
            cout<<day<<endl;
            cout<<"\n";

        }
    }
    cout<<"\n";
    flag=0;
    time_t t=time(NULL);
    tm* timeptr=localtime(&t);

    while(flag==0)
    {
        while(true)
        {
            cout<<"8>YEAR:-";
            cin>>year;
            if(cin.good())
                break;
            else
            {
                cout<<"INVALID INPUT\n";
                system("pause");
                system("cls");
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(),'\n');
                cout<<"PLEASE ENTER YOUR DETAILS BELOW\n";
                cout<<"1>FIRST NAME:-";
                cout<<fname<<endl;
                cout<<"\n";
                cout<<"2>MIDDLE NAME:-";
                cout<<mname<<endl;
                cout<<"\n";
                cout<<"3>LAST NAME:-";
                cout<<lname<<endl;
                cout<<"\n";
                cout<<"4>USERNAME:-";
                cout<<uname<<endl;
                cout<<"\n";
                cout<<"5>PASSWORD:-";
                cout<<password<<endl;
                cout<<"\n";
                cout<<"ENTER YOUR DATE OF BIRTH DETAILS BELOW\n";
                cout<<"\n";
                cout<<"6>DATE:-";
                cout<<day<<endl;
                cout<<"\n";
                cout<<"7>MONTH:-";
                cout<<month<<endl;
                cout<<"\n";

            }
        }
        try
        {
            if(year>(timeptr->tm_year+1900)||year<1900||((timeptr->tm_year+1900)-year)<18)
                throw year;
            else
                flag=1;
        }
        catch(int year)
        {
            cout<<"PLEASE ENTER A VALID YEAR(YOU ALSO SHOULD BE 18+)\n";
            system("pause");
            system("cls");
            cout<<"PLEASE ENTER YOUR DETAILS BELOW\n";
            cout<<"1>FIRST NAME:-";
            cout<<fname<<endl;
            cout<<"\n";
            cout<<"2>MIDDLE NAME:-";
            cout<<mname<<endl;
            cout<<"\n";
            cout<<"3>LAST NAME:-";
            cout<<lname<<endl;
            cout<<"\n";
            cout<<"4>USERNAME:-";
            cout<<uname<<endl;
            cout<<"\n";
            cout<<"5>PASSWORD:-";
            cout<<password<<endl;
            cout<<"\n";
            cout<<"ENTER YOUR DATE OF BIRTH DETAILS BELOW\n";
            cout<<"\n";
            cout<<"6>DATE:-";
            cout<<day<<endl;
            cout<<"\n";
            cout<<"7>MONTH:-";
            cout<<month<<endl;
            cout<<"\n";

        }

    }
    cout<<"\n";
    flag=0;
    stringstream d,m,y;
    d<<day;
    d>>dd;
    m<<month;
    m>>mm;
    y<<year;
    y>>yyyy;
    dob=dd+"/"+mm+"/"+yyyy;
    flag=0;
    while(flag==0)
    {

        cout<<"9>GENDER (M=Male/F=Female/O=Other)?:-";
        cin>>gen;
        try
        {
            if(gen=='M'||gen=='m'||gen=='F'||gen=='f'||gen=='O'||gen=='o')
                flag=1;
            else
                throw gen;
        }
        catch(char gen)
        {
            cout<<"PLEASE ENTER A  VALID GENDER\n";
            system("pause");
            system("cls");
            cout<<"PLEASE ENTER YOUR DETAILS BELOW\n";
            cout<<"1>FIRST NAME:-";
            cout<<fname<<endl;
            cout<<"\n";
            cout<<"2>MIDDLE NAME:-";
            cout<<mname<<endl;
            cout<<"\n";
            cout<<"3>LAST NAME:-";
            cout<<lname<<endl;
            cout<<"\n";
            cout<<"4>USERNAME:-";
            cout<<uname<<endl;
            cout<<"\n";
            cout<<"5>PASSWWORD:-";
            cout<<password<<endl;
            cout<<"\n";
            cout<<"ENTER YOUR DATE OF BIRTH DETAILS BELOW\n";
            cout<<"\n";
            cout<<"6>DATE:-";
            cout<<day<<endl;
            cout<<"\n";
            cout<<"7>MONTH:-";
            cout<<month<<endl;
            cout<<"\n";
            cout<<"8>YEAR:-";
            cout<<year<<endl;
            cout<<"\n";
        }
    }
    flag=0;

    string dirname="Accounts/"+uname;
    fullname=fname+" "+mname+" "+lname;
    char dname[50]= {};


    dirname.copy(dname,dirname.length(),0);
    mkdir(dname);

    string foldpath= dirname + "/Profile.txt";
    char filename[50]= {};
    foldpath.copy(filename,foldpath.length(),0);
    ofstream file(filename);
    file<<fullname<<endl;
    file<<uname<<endl;
    file<<password<<endl;
    file<<dob<<endl;
    if(gen=='M'||gen=='m')
    {
        gender="male";
        file<<gender<<endl;
    }
    if(gen=='F'||gen=='f')
    {
        gender="female";
        file<<gender<<endl;
    }
    if(gen=='O'||gen=='o')
    {
        gender="other";
        file<<gender<<endl;
    }

    file.close();


    cout<<"YOUR PROFILE WAS SUCCESSFULLY CREATED!!!\n";
    cout<<"NOW YOU ARE BEING REDIRECTED TO THE MAINPAGE..\n";
    system("pause");
    system("cls");
}

