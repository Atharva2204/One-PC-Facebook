#ifndef MAINPAGE_H
#define MAINPAGE_H

using namespace std;

class MainPage
{
public:

    MainPage();
    virtual ~MainPage();
    // void AfterLogin();

protected:

private:
};

#endif // MAINPAGE_H
