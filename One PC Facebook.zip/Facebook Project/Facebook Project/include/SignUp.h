#ifndef SIGNUP_H
#define SIGNUP_H

#include <MainPage.h>
#include<string>
using namespace std;
class SignUp : public MainPage
{
public:
    /*char name[50]="\0";
    char uname[50]="\0";
    char password[20]="\0";
    char dob[10]="\0";
    char gender='\0';*/
    string fname;
    string mname;
    string lname;
    string fullname;
    string uname;
    string password;
    string dob;
    string dd,mm,yyyy;
    int day,month,year;
    string gender;
    char gen;
    SignUp();
    virtual ~SignUp();
    void  getdetails();


protected:

private:
};

#endif // SIGNUP_H
