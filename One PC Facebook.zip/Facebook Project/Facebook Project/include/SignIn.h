#ifndef SIGNIN_H
#define SIGNIN_H

#include <MainPage.h>
#include<string>
#include<iostream>
using namespace std;

class SignIn : public MainPage
{
public:
    int Signinscreen();
    void Viewdetails();
    string uname;
    string uname2;
    string password;
    string chkpass;
    //int enterdetails();
    void AfterLogin();
    int enterdetails();
    void edit_details();
    void edit_name();
    void edit_username();
    void edit_password();
    void edit_birthdate();
    void edit_gender();

    // void AfterLoginAdmin();
    SignIn();
    virtual ~SignIn();

protected:

private:
};

#endif // SIGNIN_H
